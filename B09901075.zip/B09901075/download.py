import gdown

id = "1cNsuEYlW-xIHInC-s3UekQnMHLLeHxhQ"
gdown.download(id=id, quiet=False)
# url = "https://drive.google.com/uc?id=1cNsuEYlW-xIHInC-s3UekQnMHLLeHxhQ"
# gdown.download(url=url, quiet=False)