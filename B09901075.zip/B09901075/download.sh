#!/bin/bash

pip install -r requirements.txt

python3 download.py
unzip datasets.zip
rm datasets.zip
